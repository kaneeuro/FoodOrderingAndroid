package ucad.edu.sn.sddreservation.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Reservation implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private Long idReservation;
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateReservation;
	private Integer nombrePlaces;
	@Column(unique = true, nullable = false)
	private Long code;
	private Integer numeroSiege;
	private Integer statut;
	@ManyToOne()
	@JoinColumn(name = "id_voyage", nullable = false)
	private Voyage voyage;
	@ManyToOne()
	@JoinColumn(name = "id_client", nullable = false)
	private Client client;
	
	public Reservation() {
		super();
	}

	public Reservation(Date dateReservation, Integer nombrePlaces, Long code, Integer numeroSiege, Integer statut,
			Voyage voyage, Client client) {
		super();
		this.dateReservation = dateReservation;
		this.nombrePlaces = nombrePlaces;
		this.code = code;
		this.numeroSiege = numeroSiege;
		this.statut = statut;
		this.voyage = voyage;
		this.client = client;
	}

	public Long getIdReservation() {
		return idReservation;
	}

	public void setIdReservation(Long idReservation) {
		this.idReservation = idReservation;
	}

	public Date getDateReservation() {
		return dateReservation;
	}

	public void setDateReservation(Date dateReservation) {
		this.dateReservation = dateReservation;
	}

	public Integer getNombrePlaces() {
		return nombrePlaces;
	}

	public void setNombrePlaces(Integer nombrePlaces) {
		this.nombrePlaces = nombrePlaces;
	}

	public Long getCode() {
		return code;
	}

	public void setCode(Long code) {
		this.code = code;
	}

	public Integer getNumeroSiege() {
		return numeroSiege;
	}

	public void setNumeroSiege(Integer numeroSiege) {
		this.numeroSiege = numeroSiege;
	}

	public Integer getStatut() {
		return statut;
	}

	public void setStatut(Integer statut) {
		this.statut = statut;
	}

	public Voyage getVoyage() {
		return voyage;
	}

	public void setVoyage(Voyage voyage) {
		this.voyage = voyage;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

}
