package ucad.edu.sn.sddreservation.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ucad.edu.sn.sddreservation.dao.LigneRepository;
import ucad.edu.sn.sddreservation.entities.Ligne;

@RestController
public class LigneRestService {
	
	@Autowired
	LigneRepository ligneRepository;
	
	@RequestMapping(value="/lignes", method=RequestMethod.GET)
	public List<Ligne> findAll() {
		return ligneRepository.findAll();
	}
	
	@RequestMapping(value="/ligne/{id}", method=RequestMethod.GET)
	public Ligne findOne(@PathVariable Long id) {
		return ligneRepository.findOne(id);
	}
	
	 // methode permettant permettant de retourner la ligne correspondante au nom renseigné
	@RequestMapping(value="/ligneByNom/{nomLigne}", method=RequestMethod.GET)
	public Ligne findByNomLigne(@PathVariable String nomLigne) {
		return ligneRepository.findByNomLigne(nomLigne);
	}

	//methode permettant de retrouvée les lignes correspondantes à la ville de départ renseignée 
	@RequestMapping(value="/ligneByVilleDepart/{villeDepart}", method=RequestMethod.GET)
	public List<Ligne> findByVilleDepart(@PathVariable String villeDepart) {
		return ligneRepository.findByVilleDepart(villeDepart);
	}
	
	//methode permettant de retrouvée les lignes correspondantes à la ville de destination renseignée
	@RequestMapping(value="/ligneByVilleArrivee/{villeArrivee}", method=RequestMethod.GET)
	public List<Ligne> findByVilleArrivee(@PathVariable String villeArrivee) {
		return ligneRepository.findByVilleArrivee(villeArrivee);
	}
		
	//methode permettant de retrouvée les lignes correspondantes à la ville de départ et de destination renseignées
	@RequestMapping(value="/ligneByVilleDepartAndVilleArrivee/{villeDepart}/{villeArrivee}", method=RequestMethod.GET)
	public List<Ligne> findByVilleDepartAndVilleArrivee(@PathVariable String villeDepart,@PathVariable String villeArrivee) {
		return ligneRepository.findByVilleDepartAndVilleArrivee(villeDepart, villeArrivee);
	}
	
	@RequestMapping(value="/ligne", method=RequestMethod.POST)
	public Ligne save(@RequestBody Ligne ligne) {
		return ligneRepository.save(ligne);
	}
	
	@RequestMapping(value="/ligne/{id}", method=RequestMethod.PUT)
	public Ligne update(@PathVariable Long id, @RequestBody Ligne ligne) {
		ligne.setIdLigne(id);
		return ligneRepository.save(ligne);
	}
	
	@RequestMapping(value="/ligne/{id}", method=RequestMethod.DELETE)
	public boolean delete(@PathVariable Long id) {
		try {
			ligneRepository.delete(id);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

}
