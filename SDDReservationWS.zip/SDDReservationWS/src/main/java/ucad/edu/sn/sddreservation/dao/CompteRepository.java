package ucad.edu.sn.sddreservation.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import ucad.edu.sn.sddreservation.entities.Compte;

public interface CompteRepository extends JpaRepository<Compte, Long> {

}
