package ucad.edu.sn.sddreservation.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ucad.edu.sn.sddreservation.dao.ClientRepository;
import ucad.edu.sn.sddreservation.dao.ReservationRepository;
import ucad.edu.sn.sddreservation.dao.ReservationTemporaireRepository;
import ucad.edu.sn.sddreservation.entities.Client;
import ucad.edu.sn.sddreservation.entities.Reservation;
import ucad.edu.sn.sddreservation.entities.ReservationTemporaire;

@RestController
public class ReservationRestService {

	@Autowired
	ReservationRepository reservationRepository;
	@Autowired
	ReservationTemporaireRepository reservationTemporaireRepository;
	@Autowired
	ClientRepository clientRepository;
	
	@RequestMapping(value="/reservations", method=RequestMethod.GET)
	public List<Reservation> findAll() {
		return reservationRepository.findAll();
	}
	
	@RequestMapping(value="/reservation/{id}", method=RequestMethod.GET)
	public Reservation findOne(@PathVariable Long id) {
		return reservationRepository.findOne(id);
	}
	
	//methode permettant de retourner la reservation à partir du code renseigné 
	@RequestMapping(value="/reservationByCode/{code}", method=RequestMethod.GET)
	public Reservation findByCode(@PathVariable Long code) {
		return reservationRepository.findByCode(code);
	}
	
	// methode permettant d'effectuer le paiement par Orange Money en comparant le solde et le prix du voyage
	@Transactional
	@RequestMapping(value="/payerParOrangeMoney/{code}", method=RequestMethod.GET)
	public ReservationTemporaire payerParOrangeMoney(@PathVariable Long code) {
		Double solde = 5000.0;
		ReservationTemporaire reservationTemporaire= reservationTemporaireRepository.findByCode(code);
		if (solde>=(reservationTemporaire.getVoyage().getPrix()*reservationTemporaire.getNombrePlaces())) {
			reservationTemporaire.setStatut(1);
			reservationTemporaireRepository.save(reservationTemporaire);
			return reservationTemporaire;
		}
		return reservationTemporaire; 
	}
	
	@Transactional
	@RequestMapping(value="/saveReservation", method=RequestMethod.POST)
	public Reservation saveReservation(@RequestParam Long code) {
		ReservationTemporaire rt = reservationTemporaireRepository.findByCode(code);
		Client client = new Client(rt.getNom(), rt.getPrenom(), rt.getSexe(), rt.getDateNaissance(), rt.getEmail(),
				rt.getAdresse(), rt.getTelephone(), rt.getTypePiece(), rt.getNumeroPiece(), rt.getMatricule(), rt.getProfil());
		
		Reservation reservation = new Reservation(rt.getDateReservation(), rt.getNombrePlaces(), rt.getCode(),
				rt.getNumeroSiege(), rt.getStatut(), rt.getVoyage(), client);
		
		clientRepository.save(client);
		reservationRepository.save(reservation);
		//reservationTemporaireRepository.delete(rt); // laisser pour la journalisation
		return reservation;
	}
	
	@RequestMapping(value="/reservation", method=RequestMethod.POST)
	public Reservation save(@RequestBody Reservation reservation) {	
		return reservationRepository.save(reservation);
	}
	
	
	@RequestMapping(value="/reservation/{id}", method=RequestMethod.PUT)
	public Reservation update(@PathVariable Long id, @RequestBody Reservation reservation) {
		reservation.setIdReservation(id);
		return reservationRepository.save(reservation);
	}
	
	@RequestMapping(value="/reservation/{id}", method=RequestMethod.DELETE)
	public boolean delete(@PathVariable Long id) {
		try {
			reservationRepository.delete(id);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}
