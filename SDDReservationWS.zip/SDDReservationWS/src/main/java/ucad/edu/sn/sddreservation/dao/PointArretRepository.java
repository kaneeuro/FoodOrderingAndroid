package ucad.edu.sn.sddreservation.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ucad.edu.sn.sddreservation.entities.PointArret;

public interface PointArretRepository extends JpaRepository<PointArret, Long> {
	
	public List<PointArret> findByVille(String ville);
}
