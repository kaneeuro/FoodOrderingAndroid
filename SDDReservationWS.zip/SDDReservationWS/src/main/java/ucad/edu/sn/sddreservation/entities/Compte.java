package ucad.edu.sn.sddreservation.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Compte implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private Long idCompte;
	@Column(unique = true, nullable = false)
	private String login;
	@Column(nullable = false)
	private String password;
	@OneToOne
	@JoinColumn(name = "id_agent", unique = true, nullable = false)
	private Agent agent;

	public Compte() {
		super();
	}

	public Compte(String login, String password, Agent agent) {
		this.login = login;
		this.password = password;
		this.agent = agent;
	}

	public Long getIdCompte() {
		return idCompte;
	}

	public void setIdCompte(Long idCompte) {
		this.idCompte = idCompte;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Agent getAgent() {
		return agent;
	}

	public void setAgent(Agent agent) {
		this.agent = agent;
	}
	
}
