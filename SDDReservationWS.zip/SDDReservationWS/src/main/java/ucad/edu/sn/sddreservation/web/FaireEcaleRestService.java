package ucad.edu.sn.sddreservation.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ucad.edu.sn.sddreservation.dao.FaireEscaleRepository;
import ucad.edu.sn.sddreservation.entities.FaireEscale;
import ucad.edu.sn.sddreservation.entities.Ligne;

@RestController
public class FaireEcaleRestService {
	
	@Autowired
	FaireEscaleRepository faireEscaleRepository;
	
	@RequestMapping(value="/escales", method=RequestMethod.GET)
	public List<FaireEscale> findAll() {
		return faireEscaleRepository.findAll();
	}
	
	@RequestMapping(value="/escale/{id}", method=RequestMethod.GET)
	public FaireEscale findOne(@PathVariable Long id) {
		return faireEscaleRepository.findOne(id);
	}
	
	@RequestMapping(value="/escaleByLigne", method=RequestMethod.POST)
	public List<FaireEscale> findByLigne(@RequestBody Ligne ligne ) {
		return faireEscaleRepository.findByLigne(ligne);
	}
	
	@RequestMapping(value="/escale", method=RequestMethod.POST)
	public FaireEscale save(@RequestBody FaireEscale ville) {
		return faireEscaleRepository.save(ville);
	}
	
	@RequestMapping(value="/escale/{id}", method=RequestMethod.PUT)
	public FaireEscale update(@PathVariable Long id, @RequestBody FaireEscale ville) {
		ville.setIdEscale(id);
		return faireEscaleRepository.save(ville);
	}
	
	@RequestMapping(value="/escale/{id}", method=RequestMethod.DELETE)
	public boolean delete(@PathVariable Long id) {
		try {
			faireEscaleRepository.delete(id);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

}
