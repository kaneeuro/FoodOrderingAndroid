package ucad.edu.sn.sddreservation.dao;

import org.springframework.data.jpa.repository.JpaRepository;


import ucad.edu.sn.sddreservation.entities.Client;

public interface ClientRepository extends JpaRepository<Client, Long> {
	
	public Client findByNomAndPrenom(String nom, String prenom);
	public Client findByTelephone(String telephone);

}
