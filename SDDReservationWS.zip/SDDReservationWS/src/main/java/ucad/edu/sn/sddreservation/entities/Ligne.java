package ucad.edu.sn.sddreservation.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
public class Ligne implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private Long idLigne;
	@Column(nullable = false)
	private String nomLigne;
	@Column(nullable = false)
	private String villeDepart;
	@Column(nullable = false)
	private String villeArrivee;
	@Column(nullable = false)
	private int nombreVoyageParJour;
	@ManyToOne
	@JoinColumn(name = "id_agent", nullable = false)
	private Agent agent;
	
	public Ligne() {
		super();
	}

	public Ligne(String nomLigne, String villeDepart, String villeArrivee, int nombreVoyageParJour, Agent agent) {
		super();
		this.nomLigne = nomLigne;
		this.villeDepart = villeDepart;
		this.villeArrivee = villeArrivee;
		this.nombreVoyageParJour = nombreVoyageParJour;
		this.agent = agent;
	}

	public Long getIdLigne() {
		return idLigne;
	}

	public void setIdLigne(Long idLigne) {
		this.idLigne = idLigne;
	}

	public String getNomLigne() {
		return nomLigne;
	}

	public void setNomLigne(String nomLigne) {
		this.nomLigne = nomLigne;
	}

	public String getVilleDepart() {
		return villeDepart;
	}

	public void setVilleDepart(String villeDepart) {
		this.villeDepart = villeDepart;
	}

	public String getVilleArrivee() {
		return villeArrivee;
	}

	public void setVilleArrivee(String villeArrivee) {
		this.villeArrivee = villeArrivee;
	}

	public int getNombreVoyageParJour() {
		return nombreVoyageParJour;
	}

	public void setNombreVoyageParJour(int nombreVoyageParJour) {
		this.nombreVoyageParJour = nombreVoyageParJour;
	}

	public Agent getAgent() {
		return agent;
	}

	public void setAgent(Agent agent) {
		this.agent = agent;
	}

}
