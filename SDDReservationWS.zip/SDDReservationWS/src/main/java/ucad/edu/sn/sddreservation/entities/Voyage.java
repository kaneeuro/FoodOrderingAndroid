package ucad.edu.sn.sddreservation.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Voyage implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	private Long idVoyage;
	@Column(nullable = false)
	@Temporal(TemporalType.DATE)
	private Date dateDepart;
	@Temporal(TemporalType.DATE)
	private Date dateArrivee;
	@Column(nullable = false)
	private String heureDepart;
	private String heureArrivee;
	private double prix;
	private String bagages;
	private Integer nombrePlacesReservees; // doit être égal à 0 au moment de la création du voyage
	@ManyToOne()
	@JoinColumn(name = "id_bus", nullable = false)
	private Bus bus;
	@ManyToOne()
	@JoinColumn(name = "id_ligne", nullable = false)
	private Ligne ligne;

	public Voyage() {
		super();
	}

	
	public Voyage(Date dateDepart, Date dateArrivee, String heureDepart, String heureArrivee, double prix,
			String bagages, Integer nombrePlacesReservees, Bus bus, Ligne ligne) {
		super();
		this.dateDepart = dateDepart;
		this.dateArrivee = dateArrivee;
		this.heureDepart = heureDepart;
		this.heureArrivee = heureArrivee;
		this.prix = prix;
		this.bagages = bagages;
		this.nombrePlacesReservees = nombrePlacesReservees;
		this.bus = bus;
		this.ligne = ligne;
	}


	public Long getIdVoyage() {
		return idVoyage;
	}

	public void setIdVoyage(Long idVoyage) {
		this.idVoyage = idVoyage;
	}



	public Date getDateDepart() {
		return dateDepart;
	}


	public void setDateDepart(Date dateDepart) {
		this.dateDepart = dateDepart;
	}


	public Date getDateArrivee() {
		return dateArrivee;
	}


	public void setDateArrivee(Date dateArrivee) {
		this.dateArrivee = dateArrivee;
	}


	public String getHeureArrivee() {
		return heureArrivee;
	}


	public void setHeureArrivee(String heureArrivee) {
		this.heureArrivee = heureArrivee;
	}


	public String getHeureDepart() {
		return heureDepart;
	}

	public void setHeureDepart(String heureDepart) {
		this.heureDepart = heureDepart;
	}

	public double getPrix() {
		return prix;
	}

	public void setPrix(double prix) {
		this.prix = prix;
	}

	public String getBagages() {
		return bagages;
	}

	public void setBagages(String bagages) {
		this.bagages = bagages;
	}

	public Integer getNombrePlacesReservees() {
		return nombrePlacesReservees;
	}

	public void setNombrePlacesReservees(Integer nombrePlacesReservees) {
		this.nombrePlacesReservees = nombrePlacesReservees;
	}

	public Bus getBus() {
		return bus;
	}

	public void setBus(Bus bus) {
		this.bus = bus;
	}

	public Ligne getLigne() {
		return ligne;
	}

	public void setLigne(Ligne ligne) {
		this.ligne = ligne;
	}
	
}
