package ucad.edu.sn.sddreservation.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ucad.edu.sn.sddreservation.entities.ReservationTemporaire;
import ucad.edu.sn.sddreservation.entities.Voyage;

public interface ReservationTemporaireRepository extends JpaRepository<ReservationTemporaire, Long> {

	public ReservationTemporaire findByCode(Long code);
	public List<ReservationTemporaire> findByVoyage(Voyage voyage); 
}
