package ucad.edu.sn.sddreservation.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ucad.edu.sn.sddreservation.entities.FaireEscale;
import ucad.edu.sn.sddreservation.entities.Ligne;
import ucad.edu.sn.sddreservation.entities.PointArret;

public interface FaireEscaleRepository extends JpaRepository<FaireEscale, Long> {
	
	public List<FaireEscale> findByPointArret(PointArret pointArret);
	public List<FaireEscale> findByLigne(Ligne ligne);
}
