package ucad.edu.sn.sddreservation.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ucad.edu.sn.sddreservation.dao.PointArretRepository;
import ucad.edu.sn.sddreservation.entities.PointArret;

@RestController
public class PointArretRestService {
	
	@Autowired
	PointArretRepository pointArretRepository;
	
	@RequestMapping(value="/arrets", method=RequestMethod.GET)
	public List<PointArret> findAll() {
		return pointArretRepository.findAll();
	}
	
	@RequestMapping(value="/arret/{id}", method=RequestMethod.GET)
	public PointArret findOne(@PathVariable Long id) {
		return pointArretRepository.findOne(id);
	}
	
	@RequestMapping(value="/arretByVille/{ville}", method=RequestMethod.GET)
	public List<PointArret> findByVille(@PathVariable String ville) {
		return pointArretRepository.findByVille(ville);
		
	}
	
	@RequestMapping(value="/arret", method=RequestMethod.POST)
	public PointArret save(@RequestBody PointArret arret) {
		return pointArretRepository.save(arret);
	}
	
	@RequestMapping(value="/arret/{id}", method=RequestMethod.PUT)
	public PointArret update(@PathVariable Long id, @RequestBody PointArret escale) {
		escale.setIdArret(id);
		return pointArretRepository.save(escale);
	}
	
	@RequestMapping(value="/arret/{id}", method=RequestMethod.DELETE)
	public boolean delete(@PathVariable Long id) {
		try {
			pointArretRepository.delete(id);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

}
