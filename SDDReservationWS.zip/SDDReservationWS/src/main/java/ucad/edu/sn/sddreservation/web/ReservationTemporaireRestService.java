package ucad.edu.sn.sddreservation.web;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ucad.edu.sn.sddreservation.dao.ReservationTemporaireRepository;
import ucad.edu.sn.sddreservation.dao.VoyageRepository;
import ucad.edu.sn.sddreservation.entities.ReservationTemporaire;
import ucad.edu.sn.sddreservation.entities.Voyage;


@RestController
public class ReservationTemporaireRestService {

	@Autowired
	ReservationTemporaireRepository reservationTemporaireRepository;
	@Autowired
	VoyageRepository voyageRepository;
	
	@RequestMapping(value="/temps", method=RequestMethod.GET)
	public List<ReservationTemporaire> findAll() {
		return reservationTemporaireRepository.findAll();
	}
	
	@RequestMapping(value="/temp/{id}", method=RequestMethod.GET)
	public ReservationTemporaire findOne(@PathVariable Long id) {
		return reservationTemporaireRepository.findOne(id);
	}
	
	//methode permettant de retourner la reservation temporaire à partir du code renseigné 
	@RequestMapping(value="/tempByCode/{code}", method=RequestMethod.GET)
	public ReservationTemporaire findByCode(@PathVariable Long code) {
		return reservationTemporaireRepository.findByCode(code);
	}
	
	@Transactional
	@RequestMapping(value="/temp", method=RequestMethod.POST)
	public ReservationTemporaire save(@RequestBody ReservationTemporaire reservTemp) {
		// Génération du code de la réservation
		reservTemp.setCode(Long.valueOf(ReservationTemporaire.randomString()));
		
		// Ajout de la date de réservation
		reservTemp.setDateReservation(new Date());
		
		// Récupération du voyage choisi par le client dans réservation temporaire
		Voyage voyage = reservTemp.getVoyage();
		
		// Incrémentation du numéro du siège à partir de la dernière réservation du même voyage
		List<ReservationTemporaire> temporaires = reservationTemporaireRepository.findByVoyage(voyage);
		if(!temporaires.isEmpty()) {
			ReservationTemporaire lastReservTemp = temporaires.get(temporaires.size()-1);
			reservTemp.setNumeroSiege(lastReservTemp.getNumeroSiege()+reservTemp.getNombrePlaces());
		}
		else {
			reservTemp.setNumeroSiege(reservTemp.getNombrePlaces());
		}
		
		// Mise à jour du nombre de places réservées dans voyage
		voyage.setNombrePlacesReservees(voyage.getNombrePlacesReservees()+reservTemp.getNombrePlaces());
		voyageRepository.save(voyage);

		// Enregistrement de la réservation 
		return reservationTemporaireRepository.save(reservTemp);
	}
	
	@RequestMapping(value="/temp/{id}", method=RequestMethod.PUT)
	public ReservationTemporaire update(@PathVariable Long id, @RequestBody ReservationTemporaire reservTemp) {
		reservTemp.setIdReservationTemporaire(id);
		return reservationTemporaireRepository.save(reservTemp);
	}
	
	//Regeneration d'un code pour une transaction si le client n'a pas recu le précédent code
	@RequestMapping(value="/genererCode/{code}", method=RequestMethod.PUT)
	public ReservationTemporaire updateCode(@PathVariable Long code) {
		ReservationTemporaire reserv= reservationTemporaireRepository.findByCode(code);
		reserv.setCode(Long.valueOf(ReservationTemporaire.randomString()));
		return reservationTemporaireRepository.save(reserv);
	}
	
	@RequestMapping(value="/temp/{id}", method=RequestMethod.DELETE)
	public boolean delete(@PathVariable Long id) {
		try {
			reservationTemporaireRepository.delete(id);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}
