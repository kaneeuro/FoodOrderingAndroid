package ucad.edu.sn.sddreservation.entities;

import java.io.Serializable;
import java.security.SecureRandom;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class ReservationTemporaire implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private Long idReservationTemporaire;
	
	// Infos du client
	private String nom;
	private String prenom;
	private String sexe;
	@Temporal(TemporalType.DATE)
	private Date dateNaissance;
	private String email;
	private String adresse;
	private String telephone;
	private String typePiece;
	private String numeroPiece;
	private String matricule;
	private String profil;

	// Infos de la réservation
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateReservation;
	private Integer nombrePlaces;
	private Long code;
	private Integer numeroSiege;
	private Integer statut;
	@ManyToOne()
	@JoinColumn(name = "id_voyage")
	private Voyage voyage;
	
	public ReservationTemporaire() {
		super();
	}


	public ReservationTemporaire(String nom, String prenom, String sexe, Date dateNaissance, String email,
			String adresse, String telephone, String typePiece, String numeroPiece, String matricule, String profil,
			Date dateReservation, Integer nombrePlaces, Long code, Integer numeroSiege, Integer statut, Voyage voyage) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.sexe = sexe;
		this.dateNaissance = dateNaissance;
		this.email = email;
		this.adresse = adresse;
		this.telephone = telephone;
		this.typePiece = typePiece;
		this.numeroPiece = numeroPiece;
		this.matricule = matricule;
		this.profil = profil;
		this.dateReservation = dateReservation;
		this.nombrePlaces = nombrePlaces;
		this.code = code;
		this.numeroSiege = numeroSiege;
		this.statut = statut;
		this.voyage = voyage;
	}


	public Long getIdReservationTemporaire() {
		return idReservationTemporaire;
	}


	public void setIdReservationTemporaire(Long idReservationTemporaire) {
		this.idReservationTemporaire = idReservationTemporaire;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public String getPrenom() {
		return prenom;
	}


	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}


	public String getSexe() {
		return sexe;
	}


	public void setSexe(String sexe) {
		this.sexe = sexe;
	}


	public Date getDateNaissance() {
		return dateNaissance;
	}


	public void setDateNaissance(Date dateNaissance) {
		this.dateNaissance = dateNaissance;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getAdresse() {
		return adresse;
	}


	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}


	public String getTelephone() {
		return telephone;
	}


	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}


	public String getTypePiece() {
		return typePiece;
	}


	public void setTypePiece(String typePiece) {
		this.typePiece = typePiece;
	}


	public String getNumeroPiece() {
		return numeroPiece;
	}


	public void setNumeroPiece(String numeroPiece) {
		this.numeroPiece = numeroPiece;
	}


	public String getMatricule() {
		return matricule;
	}


	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}


	public String getProfil() {
		return profil;
	}


	public void setProfil(String profil) {
		this.profil = profil;
	}


	public Date getDateReservation() {
		return dateReservation;
	}


	public void setDateReservation(Date dateReservation) {
		this.dateReservation = dateReservation;
	}


	public Integer getNombrePlaces() {
		return nombrePlaces;
	}


	public void setNombrePlaces(Integer nombrePlaces) {
		this.nombrePlaces = nombrePlaces;
	}


	public Long getCode() {
		return code;
	}


	public void setCode(Long code) {
		this.code = code;
	}


	public Integer getNumeroSiege() {
		return numeroSiege;
	}


	public void setNumeroSiege(Integer numeroSiege) {
		this.numeroSiege = numeroSiege;
	}


	public Integer getStatut() {
		return statut;
	}


	public void setStatut(Integer statut) {
		this.statut = statut;
	}


	public Voyage getVoyage() {
		return voyage;
	}


	public void setVoyage(Voyage voyage) {
		this.voyage = voyage;
	}
	
	// methode permettant de generer le code de la reservation 
	public static String randomString(){
		final String nb = "0123456789";
		SecureRandom rnd = new SecureRandom();
		int len = 10;
		StringBuilder sb = new StringBuilder(len);
		for(int i = 0; i < len; i++)
			sb.append(nb.charAt(rnd.nextInt(nb.length())));
		return sb.toString();
	}
}
