package ucad.edu.sn.sddreservation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SddReservationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SddReservationApplication.class, args);
	}
}
