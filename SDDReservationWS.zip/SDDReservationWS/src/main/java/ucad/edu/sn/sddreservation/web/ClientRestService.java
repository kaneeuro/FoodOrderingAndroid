package ucad.edu.sn.sddreservation.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ucad.edu.sn.sddreservation.dao.ClientRepository;
import ucad.edu.sn.sddreservation.entities.Client;

@RestController
public class ClientRestService {

	@Autowired
	ClientRepository clientRepository;
	
	@RequestMapping(value="/clients", method=RequestMethod.GET)
	public List<Client> findAll() {
		return clientRepository.findAll();
	}
	
	@RequestMapping(value="/client/{id}", method=RequestMethod.GET)
	public Client findOne(@PathVariable Long id) {
		return clientRepository.findOne(id);
	}
	
	@RequestMapping(value="/client", method=RequestMethod.POST)
	public Client save(@RequestBody Client client) {
		return clientRepository.save(client);
	}
	
	@RequestMapping(value="/client/{id}", method=RequestMethod.PUT)
	public Client update(@PathVariable Long id, @RequestBody Client client) {
		client.setIdClient(id);
		return clientRepository.save(client);
	}
	
	@RequestMapping(value="/client/{id}", method=RequestMethod.DELETE)
	public boolean delete(@PathVariable Long id) {
		try {
			clientRepository.delete(id);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}
