package ucad.edu.sn.sddreservation.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ucad.edu.sn.sddreservation.entities.Ligne;

public interface LigneRepository extends JpaRepository<Ligne, Long> {
	
	public Ligne findByNomLigne(String nomLigne);
	public List<Ligne> findByVilleDepart(String villeDepart);
	public List<Ligne> findByVilleArrivee(String villeArrivee);
	public List<Ligne> findByVilleDepartAndVilleArrivee(String villeDepart, String villeArrivee);
	
}
