package ucad.edu.sn.sddreservation.dao;

import java.util.List;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;

import ucad.edu.sn.sddreservation.entities.Ligne;
import ucad.edu.sn.sddreservation.entities.Voyage;

public interface VoyageRepository extends JpaRepository<Voyage, Long> {
	
	public List<Voyage> findByDateDepart(Date dateDepart);
	public List<Voyage> findByDateDepartAndHeureDepart(Date dateDepart,String heureDepart);
	public List<Voyage> findByDateDepartAndHeureDepartAndLigne(Date dateDepart,String heureDepart, Ligne ligne);
	public List<Voyage> findByLigneAndPrix(Ligne ligne, double prix);
	public Ligne findByIdVoyage(Long idVoyage);

	public List<Voyage> findByLigne(Ligne ligne);

}
