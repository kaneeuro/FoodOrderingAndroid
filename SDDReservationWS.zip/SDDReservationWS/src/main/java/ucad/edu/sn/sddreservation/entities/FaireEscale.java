package ucad.edu.sn.sddreservation.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
public class FaireEscale implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private Long idEscale;
	@ManyToOne()
	@JoinColumn(name = "id_arret")
	private PointArret pointArret;
	@ManyToOne()
	@JoinColumn(name = "id_ligne")
	private Ligne ligne;

	public FaireEscale() {
		super();
	}

	public FaireEscale(PointArret pointArret, Ligne ligne) {
		super();
		this.pointArret = pointArret;
		this.ligne = ligne;
	}

	public Long getIdEscale() {
		return idEscale;
	}

	public void setIdEscale(Long idEscale) {
		this.idEscale = idEscale;
	}

	public PointArret getPointArret() {
		return pointArret;
	}

	public void setPointArret(PointArret pointArret) {
		this.pointArret = pointArret;
	}

	public Ligne getLigne() {
		return ligne;
	}

	public void setLigne(Ligne ligne) {
		this.ligne = ligne;
	}
	
}
