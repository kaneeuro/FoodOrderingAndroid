package ucad.edu.sn.sddreservation.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class PointArret implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private Long idArret;
	@Column(nullable = false)
	private String ville;
	
	public PointArret() {
		super();
	}
	

	public PointArret(String ville) {
		this.ville = ville;
	}

	public Long getIdArret() {
		return idArret;
	}

	public void setIdArret(Long idArret) {
		this.idArret = idArret;
	}

	public String getVille() {
		return ville;
	}


	public void setVille(String ville) {
		this.ville = ville;
	}

}
