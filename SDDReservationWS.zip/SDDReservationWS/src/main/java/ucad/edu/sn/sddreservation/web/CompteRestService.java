package ucad.edu.sn.sddreservation.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ucad.edu.sn.sddreservation.dao.CompteRepository;
import ucad.edu.sn.sddreservation.entities.Compte;

@RestController
public class CompteRestService {

	@Autowired
	CompteRepository compteRepository;
	
	@RequestMapping(value="/comptes", method=RequestMethod.GET)
	public List<Compte> findAll() {
		return compteRepository.findAll();
	}
	
	@RequestMapping(value="/compte/{id}", method=RequestMethod.GET)
	public Compte findOne(@PathVariable Long id) {
		return compteRepository.findOne(id);
	}
	
	@RequestMapping(value="/compte", method=RequestMethod.POST)
	public Compte save(@RequestBody Compte compte) {
		return compteRepository.save(compte);
	}
	
	@RequestMapping(value="/compte/{id}", method=RequestMethod.PUT)
	public Compte update(@PathVariable Long id, @RequestBody Compte compte) {
		compte.setIdCompte(id);
		return compteRepository.save(compte);
	}
	
	@RequestMapping(value="/compte/{id}", method=RequestMethod.DELETE)
	public boolean delete(@PathVariable Long id) {
		try {
			compteRepository.delete(id);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}
