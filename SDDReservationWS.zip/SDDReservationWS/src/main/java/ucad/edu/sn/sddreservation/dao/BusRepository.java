package ucad.edu.sn.sddreservation.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import ucad.edu.sn.sddreservation.entities.Bus;

public interface BusRepository extends JpaRepository<Bus, Long> {

}
