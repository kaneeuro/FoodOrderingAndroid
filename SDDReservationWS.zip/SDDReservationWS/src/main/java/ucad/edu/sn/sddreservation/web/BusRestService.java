package ucad.edu.sn.sddreservation.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ucad.edu.sn.sddreservation.dao.BusRepository;
import ucad.edu.sn.sddreservation.entities.Bus;

@RestController
public class BusRestService {

	@Autowired
	BusRepository busRepository;
	
	@RequestMapping(value="/bus", method=RequestMethod.GET)
	public List<Bus> findAll() {
		return busRepository.findAll();
	}
	
	@RequestMapping(value="/bus/{id}", method=RequestMethod.GET)
	public Bus findOne(@PathVariable Long id) {
		return busRepository.findOne(id);
	}
	
	@RequestMapping(value="/bus", method=RequestMethod.POST)
	public Bus save(@RequestBody Bus bus) {
		return busRepository.save(bus);
	}
	
	@RequestMapping(value="/bus/{id}", method=RequestMethod.PUT)
	public Bus update(@PathVariable Long id, @RequestBody Bus bus) {
		bus.setIdBus(id);
		return busRepository.save(bus);
	}
	
	@RequestMapping(value="/bus/{id}", method=RequestMethod.DELETE)
	public boolean delete(@PathVariable Long id) {
		try {
			busRepository.delete(id);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}
