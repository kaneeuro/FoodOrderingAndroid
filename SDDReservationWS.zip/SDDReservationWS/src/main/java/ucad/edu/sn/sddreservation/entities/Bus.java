package ucad.edu.sn.sddreservation.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Bus implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private Long idBus;
	@Column(nullable = false)
	private String matricule;
	@Column(nullable = false)
	private String numeroParc;
	@Column(nullable = false)
	private int nombrePlaces;
	
	public Bus() {
		super();
	}

	public Bus(String matricule, String numeroParc, int nombrePlaces) {
		super();
		this.matricule = matricule;
		this.numeroParc = numeroParc;
		this.nombrePlaces = nombrePlaces;
	}

	public Long getIdBus() {
		return idBus;
	}

	public void setIdBus(Long idBus) {
		this.idBus = idBus;
	}

	public String getMatricule() {
		return matricule;
	}

	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}

	public String getNumeroParc() {
		return numeroParc;
	}

	public void setNumeroParc(String numeroParc) {
		this.numeroParc = numeroParc;
	}

	public int getNombrePlaces() {
		return nombrePlaces;
	}

	public void setNombrePlaces(int nombrePlaces) {
		this.nombrePlaces = nombrePlaces;
	}
	
}
