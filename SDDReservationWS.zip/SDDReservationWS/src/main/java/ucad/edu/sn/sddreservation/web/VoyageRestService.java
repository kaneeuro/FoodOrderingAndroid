package ucad.edu.sn.sddreservation.web;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ucad.edu.sn.sddreservation.dao.LigneRepository;
import ucad.edu.sn.sddreservation.dao.VoyageRepository;
import ucad.edu.sn.sddreservation.entities.Voyage;

@RestController
public class VoyageRestService {
	
	@Autowired
	VoyageRepository voyageRepository;
	@Autowired
	LigneRepository ligneRepository;
	
	@RequestMapping(value="/voyages", method=RequestMethod.GET)
	public List<Voyage> findAll() {
		return voyageRepository.findAll();
	}
	
	@RequestMapping(value="/voyage/{id}", method=RequestMethod.GET)
	public Voyage findOne(@PathVariable Long id) {
		return voyageRepository.findOne(id);
	}

	//Methode permettant de retrouver les voyages correspondants au jour de départ renseigné
	@RequestMapping(value="/voyageByJourDepart/{jourDepart}", method=RequestMethod.GET)
	public List<Voyage> findByJourDepart(@PathVariable Date dateDepart) {
		return voyageRepository.findByDateDepart(dateDepart);
		
	}
	
	//Methode permettant de retrouver les voyages correspondants au jour de départ et à l'heure donnée
	@RequestMapping(value="/voyageByJourAndHeureDepart/{jourDepart}/{heureDepart}", method=RequestMethod.GET)
	public List<Voyage> findByHeureDepart(@PathVariable Date dateDepart, @PathVariable String heureDepart) {
		return voyageRepository.findByDateDepartAndHeureDepart(dateDepart, heureDepart);
		
	}
	
	//Methode permettant de retrouver les voyages correspondants à une ligne selon la ville de départ et celle d'arrivée
	@RequestMapping(value="/voyageByLigne/{villeDepart}/{villeArrivee}", method=RequestMethod.GET)
	public List<Voyage> findByLigne(@PathVariable String villeDepart, @PathVariable String villeArrivee) {
		return voyageRepository.findByLigne(ligneRepository.findByVilleDepartAndVilleArrivee(villeDepart, villeArrivee).get(0));
	}
	
	@RequestMapping(value="/voyage", method=RequestMethod.POST)
	public Voyage save(@RequestBody Voyage voyage) {
		return voyageRepository.save(voyage);
	}
	
	@RequestMapping(value="/voyage/{id}", method=RequestMethod.PUT)
	public Voyage update(@PathVariable Long id, @RequestBody Voyage voyage) {
		voyage.setIdVoyage(id);
		return voyageRepository.save(voyage);
	}
	
	@RequestMapping(value="/voyage/{id}", method=RequestMethod.DELETE)
	public boolean delete(@PathVariable Long id) {
		try {
			voyageRepository.delete(id);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

}
