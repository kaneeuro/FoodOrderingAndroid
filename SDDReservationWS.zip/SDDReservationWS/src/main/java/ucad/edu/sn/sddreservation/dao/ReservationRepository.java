package ucad.edu.sn.sddreservation.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import ucad.edu.sn.sddreservation.entities.Reservation;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {
	
	public Reservation findByCode(Long code);

}
